//import com.mysql.cj.jdbc.MysqlDataSource;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class BuatKoneksi {
//    public static void main(String[] args) {
//        // Informasi koneksi database
//        String DB_URL = "jdbc:mysql://localhost:3306/demo_pbo?serverTimezone=Asia/Jakarta";
//        String DB_USERNAME = "root";
//        String DB_PASSWORD = "";
//
//        try {
//            // Membuat sumber data MySQL
//            MysqlDataSource dataSource = new MysqlDataSource();
//            dataSource.setUrl(DB_URL);
//            dataSource.setUser(DB_USERNAME);
//            dataSource.setPassword(DB_PASSWORD);
//
//            // Membuat koneksi menggunakan informasi database
//            Connection conn = dataSource.getConnection();
//
//            // Kueri SQL untuk SELECT
//            String kueriSelect = "SELECT nama, harga FROM Makanan WHERE kategori = ?";
//
//            // Membuat objek PreparedStatement
//            PreparedStatement ps = conn.prepareStatement(kueriSelect);
//
//            // Menentukan nilai parameter kueri
//            ps.setString(1, "cemilan");
//
//            // Mengeksekusi kueri SELECT
//            ResultSet rs = ps.executeQuery();
//
//            // Menampilkan hasil kueri
//            while (rs.next()) {
//                String nama = rs.getString("nama");
//                int harga = rs.getInt("harga");
//                System.out.println("Nama: " + nama + " dengan harga " + harga);
//            }
//
//            // Menutup ResultSet, PreparedStatement, dan koneksi
//            rs.close();
//            ps.close();
//            conn.close();
//        } catch (SQLException ex) {
//            // Menangani eksepsi yang mungkin terjadi
//            System.out.println("Eksepsi akses data: " + ex.getMessage());
//        }
//    }
//}
