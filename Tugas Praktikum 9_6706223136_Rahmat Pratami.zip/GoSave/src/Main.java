import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    private static Login loginFrame = null;

    public static void main(String[] args) {

        // Membuat objek frame Register
        Register registerFrame = new Register();
        registerFrame.setVisible(true);
        registerFrame.pack();
        registerFrame.setLocationRelativeTo(null);

        // Menambahkan ActionListener ke tombol pada frame Register
        registerFrame.addRegisterButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Memeriksa registrasi, jika berhasil, buka Login
                if (registerFrame.validateRegistration()) {
                    // Menutup frame Login yang sudah ada
                    disposeLoginFrame(loginFrame);

                    // Menutup frame Register sebelum membuka frame Login
                    registerFrame.dispose();

                    // Membuat objek frame Login baru
                    loginFrame = new Login();
                    loginFrame.setVisible(true);
                    loginFrame.pack();
                    loginFrame.setLocationRelativeTo(null);
                }
            }
        });

        // Menambahkan ActionListener ke tombol pada frame Login
        registerFrame.addLoginButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Menutup frame Register sebelum membuka frame Login
                registerFrame.dispose();

                // Membuat objek frame Login
                loginFrame = new Login();
                loginFrame.setVisible(true);
                loginFrame.pack();
                loginFrame.setLocationRelativeTo(null);
            }
        });
    }

    private static void disposeLoginFrame(Login loginFrame) {
        if (loginFrame != null) {
            loginFrame.dispose();
        }
    }
}
