//import java.sql.*;
//import java.util.Scanner;
//
//public class AplikasiTabungan {
//    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/demo_gosave?serverTimezone=Asia/Jakarta";
//    private static final String DB_USERNAME = "root";
//    private static final String DB_PASSWORD = "";
//
//    public static void main(String[] args) {
//        try {
//            Connection connection = DriverManager.getConnection(JDBC_URL, DB_USERNAME, DB_PASSWORD);
//
//            // Buat database dan tabel
//            createDatabaseAndTables(connection);
//
//            // Sisipkan data pengguna
//            insertPengguna(connection, "user1", "password1");
//
//            // Sisipkan data kategori
//            insertKategori(connection, "Pemasukan");
//
//            // Sisipkan data tabungan
//            insertDataTabungan(connection, 1, 1, 10000, "2023-01-01");
//
//            // Tampilkan data pengguna, kategori, dan data tabungan
//            selectPengguna(connection);
//            selectKategori(connection);
//            selectDataTabungan(connection);
//
//            // Operasi tambahan dari pengguna
//            operateUserInput(connection);
//
//            connection.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private static void createDatabaseAndTables(Connection connection) throws SQLException {
//        // Hapus database jika sudah ada
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("DROP DATABASE IF EXISTS demo_gosave");
//        }
//
//        // Buat database baru
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("CREATE DATABASE demo_gosave");
//        }
//
//        // Gunakan database yang baru dibuat
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("USE demo_gosave");
//        }
//
//        // Buat tabel pengguna
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("CREATE TABLE IF NOT EXISTS pengguna (" +
//                    "id INT AUTO_INCREMENT PRIMARY KEY," +
//                    "username VARCHAR(255) NOT NULL," +
//                    "password VARCHAR(255) NOT NULL)");
//        }
//
//        // Buat tabel kategori
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("CREATE TABLE IF NOT EXISTS kategori (" +
//                    "id INT AUTO_INCREMENT PRIMARY KEY," +
//                    "nama_kategori VARCHAR(255) NOT NULL)");
//        }
//
//        // Buat tabel data_tabungan
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("CREATE TABLE IF NOT EXISTS data_tabungan (" +
//                    "id INT AUTO_INCREMENT PRIMARY KEY," +
//                    "id_pengguna INT," +
//                    "id_kategori INT," +
//                    "jumlah_tabungan INT," +
//                    "tanggal_tabungan DATE," +
//                    "FOREIGN KEY (id_pengguna) REFERENCES pengguna(id)," +
//                    "FOREIGN KEY (id_kategori) REFERENCES kategori(id))");
//        }
//    }
//
//    private static void insertPengguna(Connection connection, String username, String password) throws SQLException {
//        String query = "INSERT INTO pengguna (username, password) VALUES (?, ?)";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setString(1, username);
//            preparedStatement.setString(2, password);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void insertKategori(Connection connection, String namaKategori) throws SQLException {
//        String query = "INSERT INTO kategori (nama_kategori) VALUES (?)";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setString(1, namaKategori);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void insertDataTabungan(Connection connection, int idPengguna, int idKategori, int jumlahTabungan, String tanggalTabungan) throws SQLException {
//        String query = "INSERT INTO data_tabungan (id_pengguna, id_kategori, jumlah_tabungan, tanggal_tabungan) VALUES (?, ?, ?, ?)";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setInt(1, idPengguna);
//            preparedStatement.setInt(2, idKategori);
//            preparedStatement.setInt(3, jumlahTabungan);
//            preparedStatement.setString(4, tanggalTabungan);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void selectPengguna(Connection connection) throws SQLException {
//        String query = "SELECT * FROM pengguna";
//        try (Statement statement = connection.createStatement()) {
//            ResultSet resultSet = statement.executeQuery(query);
//            while (resultSet.next()) {
//                int id = resultSet.getInt("id");
//                String username = resultSet.getString("username");
//                String password = resultSet.getString("password");
//                System.out.println("Pengguna ID: " + id + ", Username: " + username + ", Password: " + password);
//            }
//        }
//    }
//
//    private static void selectKategori(Connection connection) throws SQLException {
//        String query = "SELECT * FROM kategori";
//        try (Statement statement = connection.createStatement()) {
//            ResultSet resultSet = statement.executeQuery(query);
//            while (resultSet.next()) {
//                int id = resultSet.getInt("id");
//                String namaKategori = resultSet.getString("nama_kategori");
//                System.out.println("Kategori ID: " + id + ", Nama Kategori: " + namaKategori);
//            }
//        }
//    }
//
//    private static void selectDataTabungan(Connection connection) throws SQLException {
//        String query = "SELECT * FROM data_tabungan";
//        try (Statement statement = connection.createStatement()) {
//            ResultSet resultSet = statement.executeQuery(query);
//            while (resultSet.next()) {
//                int id = resultSet.getInt("id");
//                int idPengguna = resultSet.getInt("id_pengguna");
//                int idKategori = resultSet.getInt("id_kategori");
//                int jumlahTabungan = resultSet.getInt("jumlah_tabungan");
//                String tanggalTabungan = resultSet.getString("tanggal_tabungan");
//                System.out.println("Data Tabungan ID: " + id +
//                        ", ID Pengguna: " + idPengguna +
//                        ", ID Kategori: " + idKategori +
//                        ", Jumlah Tabungan: " + jumlahTabungan +
//                        ", Tanggal Tabungan: " + tanggalTabungan);
//            }
//        }
//    }
//
//    private static void operateUserInput(Connection connection) {
//        try {
//            Scanner scanner = new Scanner(System.in);
//            int choice;
//
//            do {
//                System.out.println("Pilih operasi tambahan:");
//                System.out.println("1. Tambah Pengguna");
//                System.out.println("2. Hapus Pengguna");
//                System.out.println("3. Tambah Kategori");
//                System.out.println("4. Hapus Kategori");
//                System.out.println("5. Tambah Data Tabungan");
//                System.out.println("6. Hapus Data Tabungan");
//                System.out.println("7. Keluar");
//
//                System.out.print("Masukkan pilihan Anda: ");
//                choice = scanner.nextInt();
//
//                switch (choice) {
//                    case 1:
//                        System.out.print("Masukkan username: ");
//                        String newUsername = scanner.next();
//                        System.out.print("Masukkan password: ");
//                        String newPassword = scanner.next();
//                        insertPengguna(connection, newUsername, newPassword);
//                        break;
//                    case 2:
//                        System.out.print("Masukkan ID pengguna yang akan dihapus: ");
//                        int userIdToDelete = scanner.nextInt();
//                        deletePengguna(connection, userIdToDelete);
//                        break;
//                    case 3:
//                        System.out.print("Masukkan nama kategori: ");
//                        String newCategory = scanner.next();
//                        insertKategori(connection, newCategory);
//                        break;
//                    case 4:
//                        System.out.print("Masukkan ID kategori yang akan dihapus: ");
//                        int categoryIdToDelete = scanner.nextInt();
//                        deleteKategori(connection, categoryIdToDelete);
//                        break;
//                    case 5:
//                        System.out.print("Masukkan ID pengguna: ");
//                        int userIdForTabungan = scanner.nextInt();
//                        System.out.print("Masukkan ID kategori: ");
//                        int categoryIdForTabungan = scanner.nextInt();
//                        System.out.print("Masukkan jumlah tabungan: ");
//                        int amountForTabungan = scanner.nextInt();
//                        System.out.print("Masukkan tanggal tabungan (YYYY-MM-DD): ");
//                        String dateForTabungan = scanner.next();
//                        insertDataTabungan(connection, userIdForTabungan, categoryIdForTabungan, amountForTabungan, dateForTabungan);
//                        break;
//                    case 6:
//                        System.out.print("Masukkan ID data tabungan yang akan dihapus: ");
//                        int dataTabunganIdToDelete = scanner.nextInt();
//                        deleteDataTabungan(connection, dataTabunganIdToDelete);
//                        break;
//                }
//            } while (choice != 7);
//
//            scanner.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private static void deletePengguna(Connection connection, int penggunaId) throws SQLException {
//        // Hapus terlebih dahulu data terkait dari tabel data_tabungan
//        deleteDataTabunganByPenggunaId(connection, penggunaId);
//
//        // Setelah itu, hapus pengguna dari tabel pengguna
//        String query = "DELETE FROM pengguna WHERE id = ?";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setInt(1, penggunaId);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void deleteDataTabunganByPenggunaId(Connection connection, int penggunaId) throws SQLException {
//        String query = "DELETE FROM data_tabungan WHERE id_pengguna = ?";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setInt(1, penggunaId);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void deleteKategori(Connection connection, int kategoriId) throws SQLException {
//        String query = "DELETE FROM kategori WHERE id = ?";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setInt(1, kategoriId);
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    private static void deleteDataTabungan(Connection connection, int dataTabunganId) throws SQLException {
//        String query = "DELETE FROM data_tabungan WHERE id = ?";
//        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//            preparedStatement.setInt(1, dataTabunganId);
//            preparedStatement.executeUpdate();
//        }
//    }
//}
