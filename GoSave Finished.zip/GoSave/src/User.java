/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author wandy
 */
public class User {
    private static int id;

    public static void setId(int id) {
        User.id = id;
    }

    public static int getId() {
        return id;
    }
    
}
