import javax.swing.JFrame;

public class Main {

    private static JFrame activeFrame = null;

    public static void main(String[] args) {
        Register registerFrame = new Register();
        setAndShowFrame(registerFrame);
        
    }

    private static void setAndShowFrame(JFrame newFrame) {
        disposeActiveFrame(activeFrame);
        activeFrame = newFrame;
        activeFrame.setVisible(true);
        activeFrame.pack();
        activeFrame.setLocationRelativeTo(null);
    }

    private static void disposeActiveFrame(JFrame frame) {
        if (frame != null) {
            frame.dispose();
        }
    }
}
