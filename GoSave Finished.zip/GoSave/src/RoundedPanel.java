import java.awt.Graphics;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class RoundedPanel extends JPanel {
    private int radius;

    public RoundedPanel(int radius) {
        this.radius = radius;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(2, 10, 2, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int width = getWidth();
        int height = getHeight();
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, width, height, radius, radius);
    }
}

