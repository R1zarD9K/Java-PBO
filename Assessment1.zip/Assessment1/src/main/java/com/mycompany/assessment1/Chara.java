/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment1;

/**
 *
 * @author exzaa
 */
import java.util.ArrayList;

public class Chara {
    private String name;
    private String race;
    private String job;
    private ArrayList<Equipment>equipmentList;
    private ArrayList<Skill> skillList;

    public Chara(String name, String race, String job) {
        this.name = name;
        this.race = race;
        this.job = job;
        this.equipmentList = new ArrayList<>();
        this.skillList = new ArrayList<>();
    }
    public void addEquipment(String type, String equipmentName, String state) {
        Equipment equipment = new Equipment(type, equipmentName, state);
        this.equipmentList.add(equipment);
    }
    
    public void getNewSkill(String skillType, String skillName, String skillEffect, int impact) {
        Skill skill = new Skill(skillType, skillName, skillEffect, impact);
        this.skillList.add(skill);
    }
    
    public String getName() {
        return name;
    }

    public String getRace() {
        return race;
    }

    public String getJob() {
        return job;
    }
    
    public void showEquipment() {
        System.out.println("Equipment for " + name + ":");
        for (Equipment equipment : equipmentList) {
            System.out.println("Type: " + equipment.getEquipmentType());
            System.out.println("equipmentName: " + equipment.getEquipmentName());
            System.out.println("State: " + equipment.getState());
            System.out.println();
        }
    }

    public void showSkill() {
        System.out.println("Skills for " + name + ":");
        for (Skill skill : skillList) {
            System.out.println("Skill Type: " + skill.getSkillType());
            System.out.println("Skill Name: " + skill.getSkillName());
            System.out.println("Skill Effect: " + skill.getSkillEffect());
            System.out.println("Impact: " + skill.getImpact());
            System.out.println();
        }
    }

    @Override
    public String toString() {
        return "Chara{" + "name=" + name + ", race=" + race + ", job=" + job + ", equipmentList=" + equipmentList + ", skillList=" + skillList + '}';
    }
}
   