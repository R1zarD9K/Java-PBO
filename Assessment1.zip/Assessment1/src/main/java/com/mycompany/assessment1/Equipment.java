/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment1;

/**
 *
 * @author exzaa
 */
public class Equipment {
    private String type;
    private String equipmentName;
    private String state;

    public Equipment(String type,String equipmentName,String state) {
        this.type = type;
        this.equipmentName = equipmentName;
        this.state = state;
    }

    public String getEquipmentType() {
        return type;
    }
    
    public String getEquipmentName() {
        return equipmentName;
    }
    
    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return "Equipment{" + "type=" + type + ", equipmentName=" + equipmentName + ", state=" + state + '}';
    }

}
