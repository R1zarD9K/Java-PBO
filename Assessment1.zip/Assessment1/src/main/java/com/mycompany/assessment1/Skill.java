/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment1;

/**
 *
 * @author exzaa
 */
public class Skill {
    private String skillType;
    private String skillName;
    private String skillEffect;
    private int impact;

    public Skill(String skillType,String skillName,String skillEffect, int impact) {
        this.skillType = skillType;
        this.skillName = skillName;
        this.skillEffect = skillEffect;
        this.impact = impact;
    }

    public String getSkillType() {
        return skillType;
    }
    
    public String getSkillName() {
        return skillName;
    }
    
    public String getSkillEffect() {
        return skillEffect;
    }

    public int getImpact() {
        return impact;
    }

    @Override
    public String toString() {
        return "Skill{" + "skillType=" + skillType + ", skillName=" + skillName + ", skillEffect=" + skillEffect + ", impact=" + impact + '}';
    }
}
