/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment1;

public class Main {
    public static void main(String[] args) {
        Player player1 = new Player("Sweet Maccaroon", "Bandung");
        Chara chara1 = new Chara("To the top", "Human", "Knight");
        Chara chara2 = new Chara("Summer breeze", "Elf", "Wizard");

        //set player dengan chara yang dimiliki
        player1.setCharaName(chara1.getName());
        player1.setCharaName(chara2.getName());

//        set chara equipment dan skill 
//        Kode Soal C| 4 dari 3 halaman 
//        Tim Dosen : CAH, RIM, MIU
        chara1.addEquipment("Clothes", "iron armor", "Defense +10");
        chara1.addEquipment("Weapon", "Iron Blade", "Attack +10");
        chara1.getNewSkill("Attack", "Double slash", "-", 10);

        // tampilkan chara
        System.out.println("Player " + player1.getPlayerName() + " memiliki " + player1.getJumChara() + " chara");
        for(int i=0; i<player1.getJumChara(); i++){
        System.out.println("Chara " + (i+1) + ", chara name: " + player1.getCharaName(i));
        }
        
        System.out.println("Data Chara");
        System.out.println("Chara Bio: ");
        System.out.println("Nama: " + chara1.getName() 
        + ", Race: " + chara1.getRace()
        + ", Job: " + chara1.getJob());
        chara1.showEquipment();
        chara1.showSkill();
        
        chara2.addEquipment("Clothes", "Obisidian armor", "Defense +69");
        chara2.addEquipment("Weapon", "Holy Axe", "Attack +79");
        chara2.getNewSkill("Attack", "Heavy Attack", "-", 100);

//        // tampilkan chara
//        System.out.println("Player " + player1.getPlayerName() + " memiliki " + player1.getJumChara() + " chara");
//        for(int i=0; i<player1.getJumChara(); i++){
//        System.out.println("Chara " + (i+1) + ", chara name: " + player1.getCharaName(i));
//        }
        
        System.out.println("Data Chara");
        System.out.println("Chara Bio: ");
        System.out.println("Nama: " + chara2.getName() 
        + ", Race: " + chara2.getRace()
        + ", Job: " + chara2.getJob());
        chara2.showEquipment();
        chara2.showSkill();

//        Event yang diadakan
//        Kode Soal C| 5 dari 3 halaman 
//        Tim Dosen : CAH, RIM, MIU
        Event event1 = new Event("Ladang Bunga Maut", "11 - 12 November 2023", "South village manor");
//
//        // chara yang mengikuti event
        event1.charaJoin(chara1);
        event1.charaJoin(chara2);
        event1.showChara();
    }
}
