/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assessment1;

/**
 *
 * @author exzaa
 */
import java.util.ArrayList;

public class Event {
    private String eventName;
    private String time;
    private String location;
    private ArrayList<Chara> listChara;

    public Event(String eventName, String time, String location) {
        this.eventName = eventName;
        this.time = time;
        this.location = location;
        this.listChara = new ArrayList<>();
    }
    
    public void charaJoin(Chara chara) {
        listChara.add(chara);
    }

    public void showChara() {
        System.out.println("Chara yang mengikuti event " + eventName + ":");
        for (Chara chara : listChara) {
            System.out.println("Name: " + chara.getName());
            System.out.println("Race: " + chara.getRace());
            System.out.println("Job: " + chara.getJob());
            System.out.println();
        }
    }
    
    public String getEventName() {
        return eventName;
    }

    public String getEventTime() {
        return time;
    }
    
    public String getEventLocation() {
        return location;
    }

    public ArrayList<Chara> getListChara() {
        return listChara;
    }

//    @Override
//    public String toString() {
//        return "Event{" + "eventName=" + eventName + ", time=" + time + ", location=" + location + ", listChara=" + listChara + '}';
//    }   
}
