package com.mycompany.assessment1;

/**
 *
 * @author exzaa
 */
import java.util.ArrayList;

class Player {
    private String playerName;
    private String location;
    private ArrayList<String> charaName;
    private int jumChara;

    public Player(String name, String location) {
        this.playerName = name;
        this.location = location;
        this.charaName = new ArrayList<>();
        this.jumChara = 0;
    }

    public void setCharaName(String charaName) {
        if (jumChara < 3) {
            this.charaName.add(charaName);
            jumChara++;
        } else {
            System.out.println("Cannot add more than 3 charas for a player.");
        }
    }

    public String getCharaName(int index) {
        return this.charaName.get(index);
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getJumChara() {
        return jumChara;
    }
}
