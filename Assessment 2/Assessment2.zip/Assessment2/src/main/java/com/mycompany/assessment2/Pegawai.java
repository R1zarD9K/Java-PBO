/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
public class Pegawai implements Pembayaran {
    private String nama;
    private String alamat;
    private String telepon;
    private String idOrder;

    public Pegawai(String nama, String alamat, String telepon) {
        this.nama = nama;
        this.alamat = alamat;
        this.telepon = telepon;
        this.idOrder = "";
    }

    public void addOrder(String idOrder) {
        this.idOrder = idOrder;
    }

    public void displayOrder() {
        // Implementasi display order
    }

    public void invoice() {
        System.out.println("Invoice for Pegawai " + nama);
        // Implementasi detail invoice
    }

    public int totalBayar(int jumlah, int harga) {
        return jumlah * harga;
    }
}
