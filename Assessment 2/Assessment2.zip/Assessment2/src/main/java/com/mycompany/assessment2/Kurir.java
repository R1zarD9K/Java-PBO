/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
import java.util.HashSet;
import java.util.Set;

public class Kurir implements Pembayaran {
    private String wilayahAntar;
    private String nama;
    private String alamat;
    private String telepon;
    private Set<String> orders;

    public Kurir(String nama, String alamat, String telepon, String wilayahAntar) {
        this.nama = nama;
        this.alamat = alamat;
        this.telepon = telepon;
        this.wilayahAntar = wilayahAntar;
        this.orders = new HashSet<>();
    }

    public void addOrder(String id) {
        orders.add(id);
    }

    public String getNamaKurir() {
        return nama;
    }

    public String getWilayahAntar() {
        return wilayahAntar;
    }

    public void displayOrder() {
        System.out.println("Orders for Kurir " + nama + ":");
        for (String orderId : orders) {
            System.out.println(" - Order ID: " + orderId);
        }
    }

    public void invoice() {
        System.out.println("Invoice for Kurir " + nama);
        System.out.println("Wilayah Antar: " + wilayahAntar);
    }

    public int totalBayar(int jumlah, int harga) {
        return jumlah * harga;
    }
}

