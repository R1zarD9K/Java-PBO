/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
import java.util.Iterator;
import java.util.TreeSet;

public class Penjaga implements Pembayaran {
    private String sesiMasuk;
    private String nama;
    private String alamat;
    private String telepon;
    private TreeSet<Order> orders;

    public Penjaga(String nama, String alamat, String telepon, String sesiMasuk) {
        this.nama = nama;
        this.alamat = alamat;
        this.telepon = telepon;
        this.sesiMasuk = sesiMasuk;
        this.orders = new TreeSet<>();
    }

    public void addOrder(String id) {
        Order order = new Order(id, "", "", 0, 0, "");
        orders.add(order);
    }

    public String getNamaPenjaga() {
        return nama;
    }

    public String getSesiMasuk() {
        return sesiMasuk;
    }

    public void displayOrder() {
        System.out.println("Orders for Penjaga " + nama + ":");
        Iterator<Order> iterator = orders.iterator();

        while (iterator.hasNext()) {
            Order order = iterator.next();
            System.out.println(" - Order ID: " + order.getIdOrder());
            System.out.println("   -----------------------------------------");
        }
    }

    public void invoice() {
        System.out.println("Invoice for Penjaga " + nama);
        // Implementasi detail invoice
    }

    @Override
    public int totalBayar(int jumlah, int harga) {
        int totalBayar = 0;
        for (Order order : orders) {
            totalBayar += order.totalBayar();
        }
        return totalBayar;
    }
}
