/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
public class Order implements Comparable<Order> {
    private String id;
    private String namaPembeli;
    private String item;
    private int jumlah;
    private int harga;
    private String alamatKirim;

    public Order(String id, String namaPembeli, String item, int jumlah, int harga, String alamat) {
        this.id = id;
        this.namaPembeli = namaPembeli;
        this.item = item;
        this.jumlah = jumlah;
        this.harga = harga;
        this.alamatKirim = alamat;
    }

    public String getIdOrder() {
        return id;
    }
    
    public String getNamaPembeli() {
        return namaPembeli;
    }
    
    public String getItem() {
        return item;
    }
    
    public int getJumlah() {
        return jumlah;
    }
    
    public int getHarga() {
        return harga;
    }
    
    public String getAlamatKirim() {
        return alamatKirim;
    }
    
    public int totalBayar() {
        return jumlah * harga;
    }

    public void invoice() {
        System.out.println("Invoice untuk pesanan dengan " + id);
        System.out.println("Atas nama " + namaPembeli);
        System.out.println(item);
        System.out.println("Jumlah : " + jumlah);
        System.out.println("Total harga: " + totalBayar());
        System.out.println("   -----------------------------------------");
    }

    @Override
    public int compareTo(Order otherOrder) {
        return this.id.compareTo(otherOrder.id);
    }
}

