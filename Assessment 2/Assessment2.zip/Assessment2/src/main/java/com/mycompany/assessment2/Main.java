/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
public class Main {
    public static void main(String[] args) {
        Kurir kurir1 = new Kurir("Dudi", "Bojongsoang", "0812123222", "Cikoneng-Ciwastra");
        Kurir kurir2 = new Kurir("Riki", "Cikoneng", "0811123212", "Setiabudi");
        
        Penjaga penjaga = new Penjaga("Rita", "Cikawalo", "085723456", "Pagi");
        
        Order item1 = new Order("A001", "Asep", "Hand sanitizer", 10, 20000, "Sukajadi");
        Order item2 = new Order("A002", "Ita", "Masker wangi", 100, 1500, "Sukajadi 2");
        PreOrder po1 = new PreOrder("B001", "Dinda", "Hair mask", 2, 50000, "Cikoneng", "25 November" + " 2023", "1 Desember 2023", 25000);
        
        penjaga.addOrder(item1.getIdOrder());
        penjaga.addOrder(item2.getIdOrder());
        penjaga.addOrder(po1.getIdOrderPO());

        kurir1.addOrder(item1.getIdOrder());
        kurir1.addOrder(item2.getIdOrder()); 
        kurir2.addOrder(po1.getIdOrderPO());

        System.out.println("Karyawan toko: " + penjaga.getNamaPenjaga());
        penjaga.displayOrder();

        System.out.println("Kurir: " + kurir1.getNamaKurir());
        System.out.println("Wilayah antar : " + kurir1.getWilayahAntar());
        kurir1.displayOrder();

        System.out.println("Kurir: " + kurir2.getNamaKurir());
        System.out.println("Wilayah antar : " + kurir2.getWilayahAntar());
        kurir2.displayOrder();
        
        System.out.println("Invoice untuk setiap pemesanan");
        item1.invoice();
        item2.invoice();
        po1.invoice();
    }
}
