/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;

/**
 *
 * @author exzaa
 */
public class PreOrder extends Order {
    private String tanggalKirim;
    private int dp;

    public PreOrder(String id, String namaPembeli, String item, int jumlah, int harga, String alamatKirim, String tanggalKirim, String _Desember_2023, int dp) {
        super(id, namaPembeli, item, jumlah, harga, alamatKirim);
        this.tanggalKirim = tanggalKirim;
        this.dp = dp;
    }
    
    public int getDP() {
        return dp;
    }
    
    public String getTanggalKirim() {
        return tanggalKirim;
    }

    public void invoice() {
        System.out.println("Invoice for PreOrder " + getIdOrder());
        System.out.println("Atas nama: " + getNamaPembeli());
        System.out.println("Item: " + getItem());
        System.out.println("Jumlah: " + getJumlah());
        System.out.println("DP yang sudah dibayar: " + getDP());
        System.out.println("Sisa bayar: " + getHarga());
        System.out.println("Tanggal kirim: " + getTanggalKirim());
        System.out.println("   -----------------------------------------");
    }

    public String getIdOrderPO() {
        return "PreOrder " + getIdOrder();
    }
}


