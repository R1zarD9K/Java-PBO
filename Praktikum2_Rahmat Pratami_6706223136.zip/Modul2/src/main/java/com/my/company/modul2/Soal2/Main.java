package com.my.company.modul2.Soal2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Departemen dept = new Departemen();
        int opsi;

        do {
            System.out.println("Menu:");
            System.out.println("1. Input Pegawai");
            System.out.println("2. Edit Pegawai");
            System.out.println("3. Menampilkan seluruh data pegawai");
            System.out.println("4. Menampilkan  data pegawai per-departemen");
            System.out.println("5. Menampilkan data pegawai berdasarkan range gaji");
            System.out.println("6. Exit");
            System.out.print("Pilih opsi: ");
            
            opsi = sc.nextInt();
            sc.nextLine(); // Consume the newline character

            switch (opsi) {
                case 1:
                    // Input Pegawai
                    System.out.print("ID: ");
                    String id = sc.nextLine();
                    System.out.print("Nama: ");
                    String nama = sc.nextLine();
                    System.out.print("Alamat: ");
                    String alamat = sc.nextLine();
                    System.out.print("Department: ");
                    String department = sc.nextLine();
                    System.out.print("Gaji: ");
                    int gaji = sc.nextInt();
                    sc.nextLine(); // Consume the newline character

                    Pegawai pegawai = new Pegawai(id, nama, alamat, department, gaji);
                    dept.inputPegawai(pegawai);
                    break;
                case 2:
                    // Edit Pegawai
                    System.out.print("Masukkan ID Pegawai yang akan diubah: ");
                    String idSearch = sc.nextLine();
                    
                    System.out.print("Nama baru (kosong jika tidak ingin mengubah): ");
                    String namaBaru = sc.nextLine();
                    System.out.print("Alamat baru (kosong jika tidak ingin mengubah): ");
                    String alamatBaru = sc.nextLine();
                    System.out.print("Department baru (kosong jika tidak ingin mengubah): ");
                    String deptBaru = sc.nextLine();
                    System.out.print("Gaji baru (0 jika tidak ingin mengubah): ");
                    int gajiBaru = sc.nextInt();
                    sc.nextLine(); // Consume the newline character

                    Pegawai pegawaiBaru = new Pegawai("", namaBaru, alamatBaru, deptBaru, gajiBaru);
                    dept.editPegawai(idSearch, pegawaiBaru);
                    break;
                case 3:
                    // Menampilkan seluruh data pegawai
                    dept.displayAllPegawai();
                    break;
                case 4:
                    // Menampilkan  data pegawai per-departemen
                    System.out.print("Masukkan nama department: ");
                    String deptName = sc.nextLine();
                    dept.displayPegawaiPerDept(deptName);
                    break;
                case 5:
                    // Menampilkan data pegawai berdasarkan range gaji
                    System.out.print("Masukkan gaji minimum: ");
                    int gajiRange = sc.nextInt();
                    dept.displayWithRangeGaji(gajiRange);
                    break;
                case 6:
                    System.out.println("Terima kasih!");
                    System.exit(0);
                default:
                    System.out.println("Opsi tidak valid.");
                    break;
            }
        } while (true);
    }
}
