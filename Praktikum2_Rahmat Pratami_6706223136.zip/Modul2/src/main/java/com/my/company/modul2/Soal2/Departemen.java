package com.my.company.modul2.Soal2;

import java.util.ArrayList;

public class Departemen {
    ArrayList<Pegawai> listPegawai = new ArrayList<>();

    public void inputPegawai(Pegawai pegawai) {
        // Challenge: Check if the employee with the same ID already exists
        if (!isEmployeeExists(pegawai.getId())) {
            listPegawai.add(pegawai);
        }
    }

    public void editPegawai(String idSearch, Pegawai pegawaiBaru) {
        for (Pegawai pegawai : listPegawai) {
            if (pegawai.getId().equals(idSearch)) {
                // Update employee information if the input is not empty
                if (!pegawaiBaru.getNama().isEmpty()) {
                    pegawai.setNama(pegawaiBaru.getNama());
                }
                // Add more fields to update as needed
            }
        }
    }

    public void displayAllPegawai() {
        for (Pegawai p : listPegawai) {
            System.out.println(p.toString());
        }
    }

    public void displayPegawaiPerDept(String department) {
        for (Pegawai p : listPegawai) {
            if (p.getDept().equalsIgnoreCase(department)) {
                System.out.println(p.toString());
            }
        }
    }

    public void displayWithRangeGaji(int range) {
        for (Pegawai p : listPegawai) {
            if (p.getGaji() > range) {
                System.out.println(p.toString());
            }
        }
    }

    // Helper method to check if an employee with the given ID already exists
    private boolean isEmployeeExists(String id) {
        for (Pegawai p : listPegawai) {
            if (p.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }
}
