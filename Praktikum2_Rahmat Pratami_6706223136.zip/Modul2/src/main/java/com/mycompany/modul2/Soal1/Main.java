package com.mycompany.modul2.Soal1;

public class Main {
    public static void main(String[] args) {
        Buku buku0 = new Buku("J.K. Rowling", "J.K. Rowling", 300000);
        Buku buku1 = new Buku("UML", "Ivar Jacobson", 400000);
        
        System.out.println("Judul: " + buku0.getJudul());
        System.out.println("Pengarang: " + buku0.getPengarang());
        System.out.println("Harga: " + buku0.getHarga());
        System.out.println();
        
        System.out.println("Judul: " + buku1.getJudul());
        System.out.println("Pengarang: " + buku1.getPengarang());
        System.out.println("Harga: " + buku1.getHarga());
        System.out.println();
    }
}

